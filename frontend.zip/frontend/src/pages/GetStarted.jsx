import React from 'react';
function GetStarted() {
  return (
    <div className="page">
      <h2>Get Started</h2>
      <p>Create an account or log in to explore job opportunities.</p>
    </div>
  );
}
export default GetStarted;














